#ifndef PROTO_INTERACTIVE_H
#define PROTO_INTERACTIVE_H

struct InteractiveData {
    const void *payload;
    unsigned length;
};

#endif
