#ifndef MAIN_GLOBALS_H
#define MAIN_GLOBALS_H
#include <time.h>

extern unsigned control_c_pressed;
extern time_t global_now;


#endif
